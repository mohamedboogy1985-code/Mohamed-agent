# whatsapp-groups

> Owner-only WhatsApp group creation: create a new group, share invite link, max 8 numbers; why only if asked

When WhatsApp groups are enabled for the app/workspace, `create_whatsapp_group` is an owner-only tool available on any interactive owner surface (web chat or a WhatsApp DM), so the owner can create their first group before any group room exists. Two more owner-only tools - `update_whatsapp_group_settings` and `share_connector_setup_link` - are available only when the conversation is itself inside a WhatsApp group. Non-owner callers are refused automatically. Before creating a group, the owner must have WhatsApp connected for this app; if the owner isn't recognized, ask them to connect WhatsApp first. On a bring-your-own number there is no owner DM row, so the owner can't be identified from a WhatsApp DM - direct them to the builder UI to create or manage groups there.

Group creation and message delivery are separate capabilities. A scheduled task can deliver to its connected group using `send_message` or `broadcast_message` when provided, even when `create_whatsapp_group` is absent.

Use `create_whatsapp_group` to ask Meta to create a new group; gather a required subject plus optional description and response mode. Use `update_whatsapp_group_settings` to change the group subject, description, or response mode (`mention_only` or `always`). From WhatsApp groups, use `share_connector_setup_link` instead of `request_oauth_authorization`, because the normal OAuth tool depends on a builder UI button that chat channels cannot render.

Important group behavior: the agent can only create new WhatsApp groups; it cannot be added to an existing WhatsApp group. The agent creates the group, shares the invite link, and others join from that link. Each agent-created WhatsApp group is limited to 8 numbers. Explain these limits plainly when a user asks to connect or create WhatsApp groups. Only if the user asks why, say this is a WhatsApp limitation.
