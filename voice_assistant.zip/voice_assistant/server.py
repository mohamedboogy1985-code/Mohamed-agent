"""خادم الويب للمساعد الصوتي متعدد الوكلاء.

التشغيل:
    python server.py

ثم افتح الواجهة:
    - بعد بناء الواجهة (npm run build في مجلد frontend): http://localhost:8000
    - أو أثناء التطوير:     cd frontend ثم npm run dev ثم افتح http://localhost:5173
"""

import sys
import os
import base64
import tempfile
import uuid
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from fastapi import FastAPI, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from dotenv import set_key, load_dotenv

from core.config import load_config
from core.llm import LLMClient
from voice.stt import STT
from voice.tts import TTS
from agents.office import build_office_agent
from agents.windows import build_windows_agent
from agents.files import build_files_agent
from agents.browser import build_browser_agent
from agents.websearch import build_websearch_agent
from agents.supervisor import Supervisor

ENV_FILE = Path(__file__).parent / ".env"

app = FastAPI(title="المساعد الصوتي متعدد الوكلاء")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

ctx = {}


class MessageIn(BaseModel):
    text: str
    confirm: bool = False


class ApiKeyIn(BaseModel):
    api_key: str


def _build_stack(cfg):
    """يبني المنسق والوكلاء بشاشة عميل LLM حديث (يستخدم مفتاح .env الحالي)."""
    llm = LLMClient(cfg)
    max_steps = cfg.get("agents", {}).get("max_steps", 8)
    return Supervisor(
        llm,
        {
            "office": build_office_agent(llm, max_steps),
            "windows": build_windows_agent(llm, max_steps),
            "files": build_files_agent(llm, max_steps),
            "browser": build_browser_agent(llm, max_steps),
            "websearch": build_websearch_agent(llm, max_steps),
        },
    )


@app.on_event("startup")
def startup():
    cfg = load_config()
    ctx["cfg"] = cfg
    ctx["stt"] = STT(cfg)
    ctx["tts"] = TTS(cfg)
    ctx["sup"] = _build_stack(cfg)
    print("\n✅ الخادم جاهز — افتح http://localhost:8000\n")


def synthesize_audio(text):
    """يولد صوت الرد ويرجعه base64، أو None لو فشل."""
    path = os.path.join(tempfile.gettempdir(), f"reply_{uuid.uuid4().hex}.mp3")
    try:
        ctx["tts"].synthesize(text, path)
        with open(path, "rb") as f:
            return base64.b64encode(f.read()).decode()
    except Exception as e:
        print(f"خطأ TTS: {e}")
        return None
    finally:
        try:
            os.remove(path)
        except OSError:
            pass


def process(text, confirm):
    flags = {"asked": None}

    def confirm_fn(desc):
        flags["asked"] = desc
        return bool(confirm)

    try:
        agent_name, task = ctx["sup"].route(text)
        if agent_name == "general":
            reply = ctx["sup"].general_reply(text)
        else:
            print(f"→ الوكيل: {agent_name} | المهمة: {task}")
            reply = ctx["sup"].run_agent(agent_name, task, confirm_fn)
    except Exception as e:
        agent_name, reply = "general", f"حدث خطأ: {e}"

    result = {
        "user_text": text,
        "agent": agent_name,
        "reply": reply,
        "needs_confirmation": False,
        "audio": None,
    }
    if flags["asked"] and not confirm:
        # أمر خطير: نرجعه للواجهة كي تطلب تأكيد المستخدم بأزرار
        result["needs_confirmation"] = True
        result["reply"] = f"⚠️ هذا الأمر يحتاج تأكيدك:\n{flags['asked']}\nهل تريد المتابعة؟"
    else:
        result["audio"] = synthesize_audio(reply)
    return result


@app.post("/api/message")
def message(msg: MessageIn):
    return process(msg.text, msg.confirm)


@app.post("/api/audio")
async def audio(file: UploadFile = File(...), confirm: str = Form("false")):
    raw = await file.read()
    suffix = os.path.splitext(file.filename or "clip.webm")[1] or ".webm"
    tmp = os.path.join(tempfile.gettempdir(), f"speech_{uuid.uuid4().hex}{suffix}")
    with open(tmp, "wb") as f:
        f.write(raw)
    try:
        text = ctx["stt"].transcribe(tmp)
    except Exception as e:
        text = ""
        print(f"خطأ STT: {e}")
    finally:
        try:
            os.remove(tmp)
        except OSError:
            pass

    if not text or not text.strip():
        return {
            "user_text": "",
            "agent": "general",
            "reply": "لم أسمع شيئًا واضحًا، جرب مرة أخرى.",
            "needs_confirmation": False,
            "audio": None,
        }
    return process(text, confirm == "true")


# ===== الإعدادات (زر مفتاح API في الواجهة) =====

def _key_status(cfg):
    """يرجع (المزود، هل المفتاح مضبوط؟)"""
    llm_cfg = cfg["llm"]
    provider = llm_cfg.get("provider", "openai")
    base_url = llm_cfg.get("base_url", "") or ""
    if provider == "ollama" or "11434" in base_url:
        return provider, True
    key = os.getenv(llm_cfg.get("api_key_env", "OPENAI_API_KEY"), "") or ""
    ok = len(key) > 20 and "XXXXXXXX" not in key.upper()
    return provider, ok


@app.get("/api/settings")
def get_settings():
    # إعادة قراءة .env حتى لو اتعدل يدويًا والسيرفر شغال
    load_dotenv(ENV_FILE, override=True)
    cfg = ctx.get("cfg") or load_config()
    provider, ok = _key_status(cfg)
    return {"provider": provider, "key_configured": ok}


@app.post("/api/settings/api-key")
def set_api_key(payload: ApiKeyIn):
    key = (payload.api_key or "").strip()
    if len(key) < 20:
        return {"ok": False, "message": "المفتاح قصير جدًا — تأكد من نسخه كاملًا"}

    # حفظ المفتاح في .env
    try:
        if not ENV_FILE.exists():
            ENV_FILE.write_text("OPENAI_API_KEY=\n", encoding="utf-8")
        set_key(str(ENV_FILE), "OPENAI_API_KEY", key)
        os.environ["OPENAI_API_KEY"] = key
    except Exception as e:
        return {"ok": False, "message": f"فشل حفظ الملف: {e}"}

    # إعادة بناء المنسق والوكلاء بالمفتاح الجديد فورًا (بدون إعادة تشغيل)
    cfg = ctx.get("cfg") or load_config()
    ctx["cfg"] = cfg
    ctx["sup"] = _build_stack(cfg)
    return {"ok": True, "message": "تم حفظ المفتاح وتفعيله بنجاح"}


# تقديم واجهة React المبنية (frontend/dist) إن وُجدت
_dist = Path(__file__).parent / "frontend" / "dist"
if _dist.exists():
    app.mount("/", StaticFiles(directory=str(_dist), html=True), name="ui")


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="127.0.0.1", port=8000)
