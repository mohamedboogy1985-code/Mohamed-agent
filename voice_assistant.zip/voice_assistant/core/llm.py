import os
from openai import OpenAI


class LLMClient:
    """عميل موحد يعمل مع OpenAI API ومع Ollama المحلي (نفس الواجهة)."""

    def __init__(self, cfg):
        llm_cfg = cfg["llm"]
        base_url = llm_cfg.get("base_url") or os.getenv("LLM_BASE_URL")
        api_key = os.getenv(llm_cfg.get("api_key_env", "OPENAI_API_KEY"), "ollama")
        self.client = OpenAI(base_url=base_url, api_key=api_key)
        self.model = llm_cfg["model"]

    def chat(self, messages, temperature=0.3, max_tokens=1024):
        resp = self.client.chat.completions.create(
            model=self.model,
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
        )
        return (resp.choices[0].message.content or "").strip()
