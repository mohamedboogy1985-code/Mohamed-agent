import os

IS_WINDOWS = os.name == "nt"


def create_document(path, content):
    """إنشاء مستند Word من نص (كل سطر فقرة)."""
    from docx import Document
    doc = Document()
    for para in str(content).split("\n"):
        doc.add_paragraph(para)
    doc.save(path)
    return f"تم إنشاء المستند: {path}"


def read_document(path):
    """قراءة نص مستند Word."""
    from docx import Document
    doc = Document(path)
    text = "\n".join(p.text for p in doc.paragraphs if p.text.strip())
    return text[:4000] if text else "المستند فارغ"


def create_spreadsheet(path, data):
    """إنشاء جدول Excel من قائمة صفوف."""
    from openpyxl import Workbook
    if not isinstance(data, list):
        raise ValueError("data يجب أن تكون قائمة صفوف")
    wb = Workbook()
    ws = wb.active
    for row in data:
        ws.append(row if isinstance(row, (list, tuple)) else [row])
    wb.save(path)
    return f"تم إنشاء الجدول ({len(data)} صف): {path}"


def read_spreadsheet(path):
    """قراءة جدول Excel."""
    from openpyxl import load_workbook
    wb = load_workbook(path, data_only=True)
    ws = wb.active
    rows = []
    for row in ws.iter_rows(values_only=True):
        rows.append(list(row))
        if len(rows) >= 50:
            rows.append(["..."])
            break
    return str(rows)


def create_presentation(path, slides):
    """إنشاء عرض PowerPoint من قائمة شرائح {title, content}."""
    from pptx import Presentation
    prs = Presentation()
    for slide in slides or []:
        layout = prs.slide_layouts[1]
        s = prs.slides.add_slide(layout)
        s.shapes.title.text = str(slide.get("title", ""))
        s.placeholders[1].text = str(slide.get("content", ""))
    prs.save(path)
    return f"تم إنشاء العرض ({len(slides or [])} شريحة): {path}"


def send_outlook_email(to, subject, body):
    """إرسال بريد عبر Outlook المثبت على الجهاز."""
    if not IS_WINDOWS:
        return "هذه الأداة تعمل على ويندوز فقط"
    import win32com.client
    outlook = win32com.client.Dispatch("Outlook.Application")
    mail = outlook.CreateItem(0)
    mail.To = to
    mail.Subject = subject
    mail.Body = body
    mail.Send()
    return f"تم إرسال البريد إلى {to}"
