import os
import time
import shutil
import zipfile

IS_WINDOWS = os.name == "nt"
DEFAULT_ROOT = "C:\\" if IS_WINDOWS else "/"


def _expand(path):
    return os.path.expanduser(str(path)) if path else path


def search_files(query, root=None):
    """البحث عن ملفات تحتوي query في اسمها."""
    root = _expand(root) or DEFAULT_ROOT
    matches, t0 = [], time.time()
    for dirpath, _dirnames, filenames in os.walk(root, onerror=lambda e: None):
        for f in filenames:
            if str(query).lower() in f.lower():
                matches.append(os.path.join(dirpath, f))
                if len(matches) >= 30:
                    return "\n".join(matches)
        if time.time() - t0 > 25:
            break
    return "\n".join(matches) if matches else "لا نتائج"


def list_directory(path=None):
    """عرض محتويات مجلد."""
    path = _expand(path) or "."
    try:
        entries = os.listdir(path)
    except FileNotFoundError:
        return "المسار غير موجود"
    dirs = [e for e in entries if os.path.isdir(os.path.join(path, e))]
    files = [e for e in entries if not os.path.isdir(os.path.join(path, e))]
    return f"مجلدات ({len(dirs)}): {dirs[:20]}\nملفات ({len(files)}): {files[:20]}"


def read_text_file(path):
    """قراءة ملف نصي (txt/md/csv/code...) حتى 4000 حرف."""
    path = _expand(path)
    with open(path, encoding="utf-8", errors="replace") as f:
        return f.read()[:4000]


def create_folder(path):
    """إنشاء مجلد جديد (يشمل المسارات المتداخلة)."""
    path = _expand(path)
    os.makedirs(path, exist_ok=True)
    return f"تم إنشاء المجلد: {path}"


def copy_item(src, dst):
    """نسخ ملف أو مجلد إلى مسار جديد."""
    src, dst = _expand(src), _expand(dst)
    if os.path.isdir(src):
        shutil.copytree(src, dst, dirs_exist_ok=True)
    else:
        shutil.copy2(src, dst)
    return f"تم النسخ: {src} -> {dst}"


def move_item(src, dst):
    """نقل أو إعادة تسمية ملف أو مجلد."""
    src, dst = _expand(src), _expand(dst)
    shutil.move(src, dst)
    return f"تم النقل: {src} -> {dst}"


def delete_item(path):
    """حذف ملف أو مجلد نهائيًا (سلة المهملات غير مستخدمة)."""
    path = _expand(path)
    if os.path.isdir(path):
        shutil.rmtree(path)
    else:
        os.remove(path)
    return f"تم الحذف: {path}"


def create_zip(folder, output=None):
    """ضغط مجلد في ملف ZIP."""
    folder = _expand(folder)
    output = _expand(output) or (folder.rstrip("/\\") + ".zip")
    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as zf:
        for dirpath, _dirs, files in os.walk(folder):
            for f in files:
                full = os.path.join(dirpath, f)
                zf.write(full, os.path.relpath(full, folder))
    return f"تم إنشاء الملف المضغوط: {output}"
