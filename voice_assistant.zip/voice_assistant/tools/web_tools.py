import re
import webbrowser
import urllib.parse
import requests
from bs4 import BeautifulSoup

HEADERS = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}


def open_url(url):
    """فتح موقع في المتصفح الافتراضي."""
    url = str(url)
    if not url.startswith("http"):
        url = "https://" + url
    webbrowser.open(url)
    return f"تم فتح الموقع في المتصفح: {url}"


def play_youtube(query):
    """فتح نتائج يوتيوب لبحث معين."""
    webbrowser.open("https://www.youtube.com/results?search_query=" + urllib.parse.quote(str(query)))
    return f"تم فتح نتائج يوتيوب في المتصفح: {query}"


def open_google_search(query):
    """فتح نتائج بحث جوجل في المتصفح."""
    webbrowser.open("https://www.google.com/search?q=" + urllib.parse.quote(str(query)))
    return f"تم فتح نتائج جوجل في المتصفح: {query}"


def web_search(query, max_results=5):
    """البحث في الإنترنت (DuckDuckGo) وإرجاع عناوين وروابط ومقتطفات."""
    max_results = int(max_results) if max_results else 5
    resp = requests.get(
        "https://html.duckduckgo.com/html/",
        params={"q": str(query)},
        headers=HEADERS,
        timeout=20,
    )
    soup = BeautifulSoup(resp.text, "html.parser")
    results = []
    for res in soup.select("div.result")[:max_results]:
        a = res.select_one("a.result__a")
        if not a:
            continue
        href = a.get("href", "")
        qs = urllib.parse.parse_qs(urllib.parse.urlparse(href).query)
        link = qs.get("uddg", [href])[0]
        snippet = res.select_one(".result__snippet")
        results.append(
            f"العنوان: {a.get_text(strip=True)}\nالرابط: {link}\nالمقتطف: {snippet.get_text(strip=True) if snippet else ''}"
        )
    if not results:
        return "لا نتائج أو تعذر الوصول لمحرك البحث"
    return "\n\n".join(results)[:3500]


def read_webpage(url):
    """قراءة نص صفحة ويب (بدون فتح متصفح)."""
    url = str(url)
    if not url.startswith("http"):
        url = "https://" + url
    resp = requests.get(url, headers=HEADERS, timeout=25)
    soup = BeautifulSoup(resp.text, "html.parser")
    for tag in soup(["script", "style", "nav", "footer", "header", "aside", "form"]):
        tag.decompose()
    text = re.sub(r"\n{3,}", "\n\n", soup.get_text("\n", strip=True))
    return text[:3500] if text else "تعذر استخراج نص من الصفحة"
