import os
import time
import subprocess
import platform

IS_WINDOWS = os.name == "nt"

APP_ALIASES = {
    "notepad": "notepad", "المفكرة": "notepad",
    "calc": "calc", "الحاسبة": "calc", "الآلة الحاسبة": "calc",
    "cmd": "cmd", "موجه الأوامر": "cmd", "سطر الأوامر": "cmd",
    "explorer": "explorer", "مستكشف الملفات": "explorer",
    "chrome": "start chrome", "كروم": "start chrome",
    "edge": "start msedge", "إيدج": "start msedge",
    "word": "start winword", "وورد": "start winword",
    "excel": "start excel", "إكسل": "start excel",
    "powerpoint": "start powerpnt", "باوربوينت": "start powerpnt",
    "outlook": "start outlook", "أوتلوك": "start outlook",
    "paint": "mspaint", "الرسام": "mspaint",
    "taskmgr": "taskmgr", "إدارة المهام": "taskmgr",
}


def _run(cmd, timeout=30):
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout, encoding="utf-8", errors="replace")
    out = (result.stdout or "").strip()
    err = (result.stderr or "").strip()
    return out or err or "تم التنفيذ"


def open_app(name):
    """فتح برنامج بالاسم."""
    name = str(name).strip()
    cmd = APP_ALIASES.get(name.lower(), name)
    _run(cmd)
    return f"تم فتح: {name}"


def run_command(command):
    """تشغيل أمر في سطر الأوامر وإرجاع الناتج."""
    return _run(str(command), timeout=60)[:2000]


def take_screenshot(path=None):
    """التقاط لقطة شاشة."""
    import pyautogui
    if not path:
        desktop = os.path.join(os.path.expanduser("~"), "Desktop")
        path = os.path.join(desktop, f"screenshot_{int(time.time())}.png")
    pyautogui.screenshot().save(path)
    return f"تم حفظ لقطة الشاشة: {path}"


def system_info():
    """معلومات النظام."""
    import psutil
    mem = psutil.virtual_memory()
    return (
        f"النظام: {platform.system()} {platform.release()} | "
        f"المعالج: {platform.processor() or platform.machine()} | "
        f"الذاكرة: {round(mem.total/1e9,1)}GB مستخدمة {mem.percent}% | "
        f"المعالجات: {os.cpu_count()}"
    )


def lock_windows():
    """قفل الجلسة الحالية."""
    if not IS_WINDOWS:
        return "هذه الأداة تعمل على ويندوز فقط"
    import ctypes
    ctypes.windll.user32.LockWorkStation()
    return "تم قفل الجلسة"


def shutdown_pc(force=False):
    """إيقاف تشغيل الحاسوب بعد 60 ثانية."""
    if not IS_WINDOWS:
        return "هذه الأداة تعمل على ويندوز فقط"
    f = "/f" if force else ""
    subprocess.Popen("shutdown /s /t 60 " + f, shell=True)
    return "سيتم إيقاف التشغيل بعد 60 ثانية (للإلغاء: shutdown /a)"
