import os
import uuid
import asyncio
import edge_tts


class TTS:
    """رد صوتي بالعربية: يجرب Edge TTS أولًا، ولو محجوب يتحول تلقائيًا إلى gTTS."""

    def __init__(self, cfg):
        tts_cfg = cfg["tts"]
        self.voice = tts_cfg.get("voice", "ar-EG-SalmaNeural")
        self.rate = tts_cfg.get("rate", "+0%")
        self.engine = tts_cfg.get("engine", "auto")  # auto | edge | gtts
        self._edge_failed = False

    def synthesize(self, text, path=None):
        """توليد ملف MP3 للنص (بدون تشغيله) وإرجاع مساره. لو لم تحدد path يُنشأ ملف مؤقت."""
        if not text:
            raise ValueError("نص فارغ")
        if not path:
            path = os.path.join(os.getenv("TEMP", "/tmp"), f"tts_{uuid.uuid4().hex}.mp3")
        self._synthesize(text, path)
        return path

    def speak(self, text):
        if not text:
            return
        print(f"🗣️ الرد: {text}")
        tmp = os.path.join(os.getenv("TEMP", "/tmp"), f"tts_{uuid.uuid4().hex}.mp3")
        try:
            self.synthesize(text, tmp)
            self._play(tmp)
        except Exception as e:
            print(f"خطأ في النطق: {e}")
        finally:
            try:
                if os.path.exists(tmp):
                    os.remove(tmp)
            except OSError:
                pass

    def _synthesize(self, text, path):
        use_edge = (
            self.engine == "edge"
            or (self.engine == "auto" and not self._edge_failed)
        )
        if use_edge:
            try:
                asyncio.run(self._edge(text, path))
                return
            except Exception as e:
                if self.engine == "edge":
                    raise
                # لو Edge محجوب على الشبكة نتحول لـ gTTS لهذه الجلسة كلها
                print(f"(Edge TTS غير متاح: {e} — التحويل إلى gTTS)")
                self._edge_failed = True
        self._gtts(text, path)

    async def _edge(self, text, path):
        communicate = edge_tts.Communicate(text, self.voice, rate=self.rate)
        await communicate.save(path)

    def _gtts(self, text, path):
        from gtts import gTTS
        gTTS(text=text, lang="ar").save(path)

    def _play(self, path):
        # soundfile يقرأ MP3 مباشرة و sounddevice يشغله (بدون pygame)
        import soundfile as sf
        import sounddevice as sd
        data, sr = sf.read(path, dtype="float32")
        sd.play(data, sr)
        sd.wait()
