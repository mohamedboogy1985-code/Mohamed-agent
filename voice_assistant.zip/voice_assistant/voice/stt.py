import os
from faster_whisper import WhisperModel

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(BASE_DIR)


class STT:
    """تحويل الصوت إلى نص محليًا باستخدام Whisper (يدعم العربية)."""

    def __init__(self, cfg):
        stt_cfg = cfg["stt"]
        self.language = stt_cfg.get("language", "ar")

        # تحميل الموديل بجوار المشروع (وليس في قرص C:) لتوفير المساحة
        cache_dir = stt_cfg.get("cache_dir") or "models_cache"
        if not os.path.isabs(cache_dir):
            cache_dir = os.path.join(PROJECT_ROOT, cache_dir)
        os.makedirs(cache_dir, exist_ok=True)

        print(f"⏳ تحميل موديل التعرف على الكلام ({stt_cfg['model']}) إلى {cache_dir} ...")
        self.model = WhisperModel(
            stt_cfg["model"],
            device="cpu",
            compute_type="int8",
            download_root=cache_dir,
        )
        print("✅ موديل الكلام جاهز")

    def transcribe(self, wav_path):
        if not wav_path or not os.path.exists(wav_path):
            return ""
        segments, _ = self.model.transcribe(wav_path, language=self.language)
        text = " ".join(s.text.strip() for s in segments).strip()
        return text
