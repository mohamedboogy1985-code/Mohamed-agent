import os
import time
import wave
import numpy as np
import sounddevice as sd


def _rms(block):
    return float(np.sqrt(np.mean(block ** 2)))


def _save_wav(frames, sample_rate, path):
    audio = np.concatenate(frames).astype(np.float32)
    pcm = (np.clip(audio, -1.0, 1.0) * 32767).astype(np.int16)
    with wave.open(path, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(sample_rate)
        wf.writeframes(pcm.tobytes())


def record(cfg, status_print=print):
    """يسجل صوت المستخدم حتى يصمت، ويعيد مسار ملف WAV أو None."""
    v = cfg["voice"]
    sr = int(v.get("sample_rate", 16000))
    speech_thr = float(v["speech_threshold"])
    silence_thr = float(v["silence_threshold"])
    silence_ms = int(v["silence_duration_ms"])
    max_ms = int(v["max_recording_ms"])

    block_size = int(sr * 0.1)  # 100ms
    started = False
    frames, pre_roll = [], []
    silent_blocks = 0
    spoken_blocks = 0
    blocks_needed = max(1, silence_ms // 100)
    max_blocks = max_ms // 100

    print("🎤 أستمع إليك...")
    try:
        with sd.InputStream(samplerate=sr, channels=1, dtype="float32", blocksize=block_size) as stream:
            t_start = time.time()
            while True:
                block, _ = stream.read(block_size)
                block = block.flatten()
                energy = _rms(block)
                pre_roll.append(block)
                if len(pre_roll) > 5:  # ثانية تخزين مسبق
                    pre_roll.pop(0)

                if not started:
                    if energy > speech_thr:
                        started = True
                        frames = list(pre_roll)
                        spoken_blocks = len(frames)
                        print("... تسجيل")
                else:
                    frames.append(block)
                    if energy > silence_thr:
                        silent_blocks = 0
                        spoken_blocks += 1
                    else:
                        silent_blocks += 1
                    elapsed_blocks = len(frames)
                    if silent_blocks >= blocks_needed and spoken_blocks > 5:
                        break
                    if elapsed_blocks >= max_blocks:
                        break
                if time.time() - t_start > 120:  # مهلة انتظار الكلام
                    return None
    except Exception as e:
        print(f"خطأ في التسجيل: {e}")
        return None

    if not frames:
        return None
    path = os.path.join(os.getenv("TEMP", "/tmp"), "voice_input.wav")
    _save_wav(frames, sr, path)
    return path
