from agents.base import Agent, Tool
from tools.files_tools import (
    search_files, list_directory, read_text_file, create_folder,
    copy_item, move_item, delete_item, create_zip,
)

SYSTEM_PROMPT = (
    "أنت 'وكيل الملفات'، متخصص في إدارة ملفات ومجلدات الحاسوب: "
    "بحث وقراءة ونسخ ونقل وحذف وضغط. حدد المسارات بدقة، "
    "وحذر المستخدم من أن الحذف نهائي قبل تأكيده."
)

DESCRIPTION = "إدارة الملفات: بحث، قراءة، نسخ، نقل، حذف، ضغط"


def build_files_agent(llm, max_steps=8):
    tools = [
        Tool(
            "search_files",
            "البحث عن ملفات بالاسم. query: جزء من اسم الملف. root: مجلد البدء (فارغ = القرص C)",
            {"query": "جزء من الاسم", "root": "مجلد البدء"},
            search_files,
        ),
        Tool(
            "list_directory",
            "عرض محتويات مجلد. path: مسار المجلد (فارغ = المجلد الحالي)",
            {"path": "مسار المجلد"},
            list_directory,
        ),
        Tool(
            "read_text_file",
            "قراءة محتوى ملف نصي. path: مسار الملف",
            {"path": "مسار الملف"},
            read_text_file,
        ),
        Tool(
            "create_folder",
            "إنشاء مجلد جديد. path: مسار المجلد",
            {"path": "مسار المجلد الجديد"},
            create_folder,
        ),
        Tool(
            "copy_item",
            "نسخ ملف أو مجلد. src: المسار الأصلي. dst: المسار الجديد",
            {"src": "المصدر", "dst": "الوجهة"},
            copy_item,
        ),
        Tool(
            "move_item",
            "نقل أو إعادة تسمية ملف أو مجلد. src: المسار الأصلي. dst: المسار الجديد",
            {"src": "المصدر", "dst": "الوجهة"},
            move_item,
        ),
        Tool(
            "delete_item",
            "حذف ملف أو مجلد نهائيًا. path: المسار",
            {"path": "المسار المراد حذفه"},
            delete_item,
            requires_confirmation=True,
        ),
        Tool(
            "create_zip",
            "ضغط مجلد في ملف ZIP. folder: مسار المجلد. output: مسار ملف ZIP (اختياري)",
            {"folder": "المجلد", "output": "مسار ملف ZIP"},
            create_zip,
        ),
    ]
    return Agent("files", SYSTEM_PROMPT, tools, llm, max_steps=max_steps, description=DESCRIPTION)
