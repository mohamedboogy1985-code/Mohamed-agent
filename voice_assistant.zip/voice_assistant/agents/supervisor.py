from agents.base import extract_json


GENERAL_PROMPT = (
    "أنت 'المساعد العام'، وكيل ذكاء اصطناعي شخصي يرد بالعربية بطريقة ودودة ومختصرة. "
    "تجيب على الأسئلة العامة وتشرح وتبسط المعلومات."
)


class Supervisor:
    """الوكيل الرئيسي: يستمع للمستخدم ويوزع المهام على الوكلاء المتخصصين."""

    def __init__(self, llm, agents):
        self.llm = llm
        self.agents = agents  # {"office": Agent, "windows": Agent}

    def route(self, text):
        names = ", ".join(self.agents.keys())
        prompt = (
            "أنت وكيل منسق (Supervisor). وصلك طلب المستخدم، حدد الوكيل المناسب.\n"
            "الوكلاء المتاحون:\n"
            f"- general: للأسئلة العامة والمحادثة\n"
            + "".join(f"- {k}: {a.description}\n" for k, a in self.agents.items())
            + '\nأعد JSON فقط: {"agent": "general|' + names.replace(", ", "|") + '", "task": "صياغة المهمة للوكيل بالعربية"}\n'
            "إذا كان الطلب مجرد حديث أو سؤال عام فاختر general."
        )
        messages = [
            {"role": "system", "content": prompt},
            {"role": "user", "content": text},
        ]
        content = self.llm.chat(messages, temperature=0.0)
        parsed = extract_json(content) or {}
        agent = parsed.get("agent", "general")
        task = parsed.get("task", text)
        if agent not in self.agents and agent != "general":
            agent = "general"
        return agent, task

    def general_reply(self, text):
        messages = [
            {"role": "system", "content": GENERAL_PROMPT},
            {"role": "user", "content": text},
        ]
        return self.llm.chat(messages, temperature=0.6)

    def run_agent(self, agent_name, task, confirm_fn):
        return self.agents[agent_name].run(task, confirm_fn=confirm_fn)
