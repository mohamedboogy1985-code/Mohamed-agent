from agents.base import Agent, Tool
from tools.office_tools import (
    create_document, read_document, create_spreadsheet, read_spreadsheet,
    create_presentation, send_outlook_email,
)

SYSTEM_PROMPT = (
    "أنت 'وكيل أوفيس'، متخصص في مهام برامج مايكروسوفت أوفيس: "
    "إنشاء وقراءة مستندات Word وجداول Excel وعروض PowerPoint، وإرسال بريد عبر Outlook. "
    "نفذ طلبات المستخدم بالأدوات المتاحة وحدد مسارات الملفات على سطح المكتب افتراضيًا."
)

DESCRIPTION = "مهام أوفيس: مستندات Word، جداول Excel، عروض PowerPoint، بريد Outlook"


def build_office_agent(llm, max_steps=8):
    tools = [
        Tool(
            "create_document",
            "إنشاء مستند Word. content: نص المستند (كل سطر فقرة). path: مسار الملف .docx",
            {"content": "نص المستند", "path": "مسار الحفظ مثل C:/Users/اسمك/Desktop/report.docx"},
            create_document,
        ),
        Tool(
            "read_document",
            "قراءة نص مستند Word. path: مسار الملف .docx",
            {"path": "مسار الملف"},
            read_document,
        ),
        Tool(
            "create_spreadsheet",
            "إنشاء جدول Excel. data: قائمة صفوف (كل صف قائمة قيم). path: مسار الملف .xlsx",
            {"data": "[[صف1], [صف2]]", "path": "مسار الحفظ"},
            create_spreadsheet,
        ),
        Tool(
            "read_spreadsheet",
            "قراءة جدول Excel وإرجاع بياناته. path: مسار الملف .xlsx",
            {"path": "مسار الملف"},
            read_spreadsheet,
        ),
        Tool(
            "create_presentation",
            "إنشاء عرض PowerPoint. slides: قائمة شرائح [{title, content}]. path: مسار الملف .pptx",
            {"slides": '[{"title": "عنوان", "content": "نص"}]', "path": "مسار الحفظ"},
            create_presentation,
        ),
        Tool(
            "send_outlook_email",
            "إرسال بريد عبر Outlook. to: عنوان المستلم. subject: الموضوع. body: نص الرسالة",
            {"to": "email@example.com", "subject": "الموضوع", "body": "نص الرسالة"},
            send_outlook_email,
            requires_confirmation=True,
        ),
    ]
    return Agent("office", SYSTEM_PROMPT, tools, llm, max_steps=max_steps, description=DESCRIPTION)
