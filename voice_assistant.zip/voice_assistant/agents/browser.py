from agents.base import Agent, Tool
from tools.web_tools import open_url, play_youtube, open_google_search

SYSTEM_PROMPT = (
    "أنت 'وكيل المتصفح'، متخصص في فتح المواقع والتصفح: فتح روابط، "
    "تشغيل يوتيوب، فتح نتائج بحث جوجل في متصفح المستخدم الافتراضي."
)

DESCRIPTION = "فتح مواقع ويب، يوتيوب، بحث جوجل في المتصفح"


def build_browser_agent(llm, max_steps=8):
    tools = [
        Tool(
            "open_url",
            "فتح موقع في المتصفح. url: رابط الموقع",
            {"url": "مثل youtube.com أو wikipedia.org"},
            open_url,
        ),
        Tool(
            "play_youtube",
            "فتح نتائج يوتيوب لكلمة أو موضوع معين. query: ما يريد المستخدم مشاهدته",
            {"query": "اسم الفيديو أو الموضوع"},
            play_youtube,
        ),
        Tool(
            "open_google_search",
            "فتح نتائج بحث جوجل في المتصفح. query: نص البحث",
            {"query": "نص البحث"},
            open_google_search,
        ),
    ]
    return Agent("browser", SYSTEM_PROMPT, tools, llm, max_steps=max_steps, description=DESCRIPTION)
