from agents.base import Agent, Tool
from tools.web_tools import web_search, read_webpage

SYSTEM_PROMPT = (
    "أنت 'وكيل بحث الويب'، متخصص في إحضار المعلومات من الإنترنت: "
    "تبحث ثم تلخص الإجابة بالعربية من عدة مصادر، وتذكر المصادر بالروابط. "
    "للأخبار أو المعلومات الحديثة ابحث دائمًا بدل الاعتماد على معرفتك."
)

DESCRIPTION = "البحث في الإنترنت عن معلومات حديثة وتلخيصها مع المصادر"


def build_websearch_agent(llm, max_steps=8):
    tools = [
        Tool(
            "web_search",
            "البحث في الإنترنت وإرجاع عناوين وروابط ومقتطفات. query: نص البحث. max_results: عدد النتائج (افتراضي 5)",
            {"query": "نص البحث", "max_results": "عدد النتائج مثل 5"},
            web_search,
        ),
        Tool(
            "read_webpage",
            "قراءة نص صفحة ويب لاستخراج تفاصيلها. url: رابط الصفحة",
            {"url": "رابط الصفحة"},
            read_webpage,
        ),
    ]
    return Agent("websearch", SYSTEM_PROMPT, tools, llm, max_steps=max_steps, description=DESCRIPTION)
