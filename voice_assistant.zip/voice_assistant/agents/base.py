import json
import re


class Tool:
    def __init__(self, name, description, parameters, func, requires_confirmation=False):
        self.name = name
        self.description = description
        self.parameters = parameters  # dict: اسم المتغير -> وصف
        self.func = func
        self.requires_confirmation = requires_confirmation

    def spec_text(self):
        args = "\n".join(f'    - "{k}": {v}' for k, v in self.parameters.items())
        return f'- {self.name}: {self.description}\n  الوسائط:\n{args}'


def extract_json(text):
    """يستخرج أول كائن JSON من نص الموديل."""
    match = re.search(r"\{.*\}", text, re.DOTALL)
    if not match:
        return None
    try:
        return json.loads(match.group(0))
    except json.JSONDecodeError:
        return None


class Agent:
    """وكيل عام: يحل المهمة عبر استدعاء أدواته خطوة بخطوة."""

    def __init__(self, name, system_prompt, tools, llm, max_steps=8, description=None):
        self.name = name
        self.description = description or name
        self.system_prompt = system_prompt
        self.tools = {t.name: t for t in tools}
        self.llm = llm
        self.max_steps = max_steps

    def _tools_text(self):
        return "\n".join(t.spec_text() for t in self.tools.values())

    def run(self, task, confirm_fn=None):
        instructions = (
            "أنت وكيل ذكاء اصطناعي ينفذ المهام خطوة بخطوة.\n"
            "في كل رد أعد JSON فقط بدون أي نص إضافي، بأحد الشكلين:\n"
            'لاستدعاء أداة: {"tool": "اسم_الأداة", "arguments": {...}}\n'
            'عند انتهاء المهمة أو للرد على المستخدم: {"final": "نص الرد بالعربية"}\n\n'
            f"الأدوات المتاحة:\n{self._tools_text()}\n"
            "لو كانت الأداة تحتاج تأكيد المستخدم فاذكر ذلك في الرد النهائي. "
            "لا تختلق أسماء أدوات غير موجودة."
        )
        messages = [
            {"role": "system", "content": f"{self.system_prompt}\n\n{instructions}"},
            {"role": "user", "content": task},
        ]

        for _ in range(self.max_steps):
            content = self.llm.chat(messages, temperature=0.2)
            parsed = extract_json(content)
            if not parsed:
                return content or "عذرًا، لم أفهم المهمة."
            if "final" in parsed:
                return parsed["final"]

            tool = self.tools.get(parsed.get("tool"))
            if not tool:
                messages.append({"role": "assistant", "content": content})
                messages.append({"role": "user", "content": f'خطأ: الأداة "{parsed.get("tool")}" غير موجودة. الأدوات: {", ".join(self.tools)}'})
                continue

            args = parsed.get("arguments") or {}
            if not isinstance(args, dict):
                args = {}
            if tool.requires_confirmation and confirm_fn is not None:
                desc = f'{tool.name} بوسائط {json.dumps(args, ensure_ascii=False)}'
                if not confirm_fn(desc):
                    messages.append({"role": "assistant", "content": content})
                    messages.append({"role": "user", "content": "المستخدم رفض التأكيد. اعرض ذلك في الرد النهائي."})
                    continue
            try:
                result = tool.func(**args)
            except TypeError as e:
                result = f"خطأ في وسائط الأداة: {e}"
            except Exception as e:
                result = f"فشل تنفيذ الأداة: {e}"
            print(f"🔧 {tool.name} -> {result}")
            messages.append({"role": "assistant", "content": content})
            messages.append({"role": "user", "content": f"نتيجة الأداة:\n{result}\nأكمل المهمة أو أنهِ بالرد النهائي."})

        return "تعذر إكمال المهمة ضمن الحد المسموح من الخطوات."
