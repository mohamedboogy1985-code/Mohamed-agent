from agents.base import Agent, Tool
from tools.windows_tools import (
    open_app, run_command, take_screenshot, system_info, lock_windows, shutdown_pc,
)

SYSTEM_PROMPT = (
    "أنت 'وكيل ويندوز'، متخصص في التحكم بالحاسوب: فتح البرامج وتشغيل الأوامر، "
    "التقاط لقطات الشاشة، معلومات النظام، القفل والإيقاف. "
    "استخدم الأدوات بالحذر مع الأوامر الخطيرة التي تحتاج تأكيد المستخدم."
)

DESCRIPTION = "مهام ويندوز: فتح برامج، أوامر، لقطة شاشة، قفل وإيقاف النظام"


def build_windows_agent(llm, max_steps=8):
    tools = [
        Tool(
            "open_app",
            "فتح برنامج بالاسم (notepad, calc, chrome, cmd, explorer...). name: اسم البرنامج أو أمر التشغيل",
            {"name": "اسم البرنامج"},
            open_app,
        ),
        Tool(
            "run_command",
            "تشغيل أمر في سطر أوامر ويندوز وإرجاع الناتج. command: الأمر الكامل",
            {"command": "الأمر"},
            run_command,
            requires_confirmation=True,
        ),
        Tool(
            "take_screenshot",
            "التقاط لقطة شاشة. path: مسار الحفظ (افتراضيًا سطح المكتب)",
            {"path": "مسار الحفظ"},
            take_screenshot,
        ),
        Tool("system_info", "معلومات عن نظام التشغيل والمعالج والذاكرة", {}, system_info),
        Tool("lock_windows", "قفل جلسة الويندوز الحالية", {}, lock_windows),
        Tool(
            "shutdown_pc",
            "إيقاف تشغيل الحاسوب بعد 60 ثانية. force: نعم لفرض الإغلاق",
            {"force": "yes/no"},
            shutdown_pc,
            requires_confirmation=True,
        ),
    ]
    return Agent("windows", SYSTEM_PROMPT, tools, llm, max_steps=max_steps, description=DESCRIPTION)
