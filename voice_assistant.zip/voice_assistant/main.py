"""المساعد الصوتي متعدد الوكلاء - نقطة التشغيل الرئيسية."""
from core.config import load_config
from core.llm import LLMClient
from voice.stt import STT
from voice.tts import TTS
from voice.recorder import record
from agents.supervisor import Supervisor
from agents.office import build_office_agent
from agents.windows import build_windows_agent
from agents.files import build_files_agent
from agents.browser import build_browser_agent
from agents.websearch import build_websearch_agent

YES_WORDS = ["نعم", "أيوه", "ايوه", "أجل", "اجل", "موافق", "تمام", "yes", "أكيد", "اكيد"]
EXIT_WORDS = ["خروج", "إيقاف البرنامج", "اوقف البرنامج", "أوقف البرنامج", "إغلاق البرنامج", "وداعا"]


def make_confirm_fn(speak, listen_text):
    """تأكيد صوتي قبل الأوامر الخطيرة."""
    def confirm(description):
        speak("هذا الأمر يحتاج تأكيدًا: " + description + ". هل تريد المتابعة؟ قل نعم أو لا.")
        answer = listen_text()
        print("الرد على التأكيد:", answer)
        return any(w in answer for w in YES_WORDS)
    return confirm


def main():
    cfg = load_config()
    llm = LLMClient(cfg)
    stt = STT(cfg)
    tts = TTS(cfg)
    max_steps = int(cfg.get("agents", {}).get("max_steps", 8))

    agents = {
        "office": build_office_agent(llm, max_steps=max_steps),
        "windows": build_windows_agent(llm, max_steps=max_steps),
        "files": build_files_agent(llm, max_steps=max_steps),
        "browser": build_browser_agent(llm, max_steps=max_steps),
        "websearch": build_websearch_agent(llm, max_steps=max_steps),
    }
    supervisor = Supervisor(llm, agents)

    def speak(text):
        tts.speak(text)

    def listen_text():
        wav = record(cfg)
        return stt.transcribe(wav)

    confirm_fn = make_confirm_fn(speak, listen_text)

    speak(
        "مرحبًا! أنا مساعدك الصوتي العام. عندي خمسة وكلاء متخصصين: "
        "أوفيس، وويندوز، والملفات، والمتصفح، وبحث الويب. تحدث وسأنفذ."
    )
    print("=" * 50)

    while True:
        try:
            wav = record(cfg)
            text = stt.transcribe(wav)
            if not text:
                continue
            print(f"\n👤 أنت: {text}")

            if any(w in text for w in EXIT_WORDS):
                speak("إلى اللقاء!")
                break

            agent_name, task = supervisor.route(text)
            print(f"➡️ الوكيل المختار: {agent_name}")

            if agent_name == "general":
                reply = supervisor.general_reply(text)
            else:
                reply = supervisor.run_agent(agent_name, task, confirm_fn)

            speak(reply)
        except KeyboardInterrupt:
            speak("تم الإيقاف. إلى اللقاء!")
            break
        except Exception as e:
            print(f"خطأ: {e}")
            speak("حدث خطأ غير متوقع، جرب مرة أخرى.")


if __name__ == "__main__":
    main()
