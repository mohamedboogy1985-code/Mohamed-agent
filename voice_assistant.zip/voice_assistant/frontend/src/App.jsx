import { useEffect, useRef, useState } from "react";

const AGENTS = {
  general: { label: "الوكيل العام", color: "#a78bfa", icon: "🤖" },
  office: { label: "وكيل أوفيس", color: "#60a5fa", icon: "📄" },
  windows: { label: "وكيل ويندوز", color: "#38bdf8", icon: "🖥️" },
  files: { label: "وكيل الملفات", color: "#fbbf24", icon: "📁" },
  browser: { label: "وكيل المتصفح", color: "#34d399", icon: "🌐" },
  websearch: { label: "وكيل بحث الويب", color: "#f87171", icon: "🔎" },
};

const STATUS = {
  idle: "",
  listening: "أستمع إليك... تحدث الآن",
  thinking: "يفكر وينفذ...",
  speaking: "يرد عليك...",
};

const KEY_ERROR = /401|invalid_api_key|Incorrect API key|api_key/i;

export default function App() {
  const [messages, setMessages] = useState([]);
  const [status, setStatus] = useState("idle");
  const [text, setText] = useState("");
  const [muted, setMuted] = useState(false);
  const [pending, setPending] = useState(null); // { payload, desc }
  const [error, setError] = useState("");

  // إعدادات مفتاح API
  const [settings, setSettings] = useState({
    open: false,
    configured: null, // null = جارٍ الفحص
    provider: "openai",
    key: "",
    show: false,
    saving: false,
    msg: "",
    issue: false, // ظهر خطأ مفتاح أثناء المحادثة
  });

  const recRef = useRef(null);
  const streamRef = useRef(null);
  const audioCtxRef = useRef(null);
  const timerRef = useRef(null);
  const bottomRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, status, pending]);

  // فحص حالة المفتاح عند فتح الصفحة
  useEffect(() => {
    fetch("/api/settings")
      .then((r) => r.json())
      .then((d) => {
        setSettings((s) => ({ ...s, configured: d.key_configured, provider: d.provider }));
        if (!d.key_configured) setSettings((s) => ({ ...s, open: true, msg: "أضف مفتاح OpenAI API للبدء" }));
      })
      .catch(() => setSettings((s) => ({ ...s, configured: null })));
  }, []);

  function addMsg(msg) {
    setMessages((m) => [...m, msg]);
  }

  function play(b64) {
    if (!b64) return;
    const audio = new Audio("data:audio/mp3;base64," + b64);
    setStatus("speaking");
    audio.onended = () => setStatus("idle");
    audio.onerror = () => setStatus("idle");
    audio.play().catch(() => setStatus("idle"));
  }

  async function post(payload) {
    setStatus("thinking");
    setError("");
    try {
      let res;
      if (payload.audio) {
        const fd = new FormData();
        fd.append("file", payload.audio, "clip.webm");
        fd.append("confirm", payload.confirm ? "true" : "false");
        res = await fetch("/api/audio", { method: "POST", body: fd });
      } else {
        res = await fetch("/api/message", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ text: payload.text, confirm: !!payload.confirm }),
        });
      }
      const data = await res.json();

      if (data.user_text) addMsg({ role: "user", text: data.user_text });

      if (data.needs_confirmation) {
        addMsg({ role: "assistant", agent: data.agent, text: data.reply });
        setPending({ payload, desc: data.reply });
      } else {
        addMsg({ role: "assistant", agent: data.agent, text: data.reply });
        if (!muted) play(data.audio);
      }

      // خطأ مفتاح API → إظهار تنبيه وفتح نافذة المفتاح
      if (KEY_ERROR.test(data.reply || "")) {
        setSettings((s) => ({ ...s, issue: true, open: true, msg: "المفتاح الحالي غير صالح — أضف مفتاحًا صحيحًا" }));
      }
    } catch (e) {
      setError("فشل الاتصال بالخادم — تأكد أن server.py يعمل في الخلفية");
    }
    setStatus("idle");
  }

  async function sendText(e) {
    e.preventDefault();
    const t = text.trim();
    if (!t || status !== "idle") return;
    setText("");
    await post({ text: t, confirm: false });
  }

  function answerConfirm(yes) {
    const p = pending;
    setPending(null);
    if (!p) return;
    if (yes) {
      post({ ...p.payload, confirm: true });
    } else {
      addMsg({ role: "assistant", agent: "general", text: "تم إلغاء الأمر." });
    }
  }

  async function saveApiKey(e) {
    e.preventDefault();
    const key = settings.key.trim();
    if (!key) return;
    setSettings((s) => ({ ...s, saving: true, msg: "" }));
    try {
      const res = await fetch("/api/settings/api-key", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ api_key: key }),
      });
      const d = await res.json();
      if (d.ok) {
        setSettings((s) => ({ ...s, configured: true, issue: false, open: false, key: "", msg: "" }));
        addMsg({ role: "assistant", agent: "general", text: "✅ تم حفظ مفتاح API — جاهز الآن، تحدث أو اكتب طلبك" });
      } else {
        setSettings((s) => ({ ...s, msg: d.message || "فشل الحفظ" }));
      }
    } catch {
      setSettings((s) => ({ ...s, msg: "فشل الاتصال بالخادم" }));
    }
    setSettings((s) => ({ ...s, saving: false }));
  }

  function cleanupAudio() {
    if (timerRef.current) clearInterval(timerRef.current);
    if (streamRef.current) streamRef.current.getTracks().forEach((t) => t.stop());
    if (audioCtxRef.current) audioCtxRef.current.close().catch(() => {});
  }

  async function startRecording() {
    if (status !== "idle") return;
    setError("");
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      const mimeType = MediaRecorder.isTypeSupported("audio/webm;codecs=opus")
        ? "audio/webm;codecs=opus"
        : "audio/webm";
      const recorder = new MediaRecorder(stream, { mimeType });
      const chunks = [];
      recorder.ondataavailable = (e) => e.data.size && chunks.push(e.data);
      recorder.onstop = async () => {
        cleanupAudio();
        const blob = new Blob(chunks, { type: "audio/webm" });
        if (blob.size < 1500) {
          setStatus("idle");
          return;
        }
        await post({ audio: blob, confirm: false });
      };
      recorder.start(250);
      recRef.current = recorder;

      // توقف تلقائي عند الصمت
      const actx = new AudioContext();
      audioCtxRef.current = actx;
      const src = actx.createMediaStreamSource(stream);
      const analyser = actx.createAnalyser();
      analyser.fftSize = 512;
      src.connect(analyser);
      const buf = new Float32Array(analyser.fftSize);
      let spoke = false;
      let silentMs = 0;
      const startedAt = Date.now();
      timerRef.current = setInterval(() => {
        analyser.getFloatTimeDomainData(buf);
        const rms = Math.sqrt(buf.reduce((a, b) => a + b * b, 0) / buf.length);
        if (rms > 0.015) {
          spoke = true;
          silentMs = 0;
        } else if (spoke) {
          silentMs += 100;
        }
        if ((spoke && silentMs >= 1500) || Date.now() - startedAt > 30000) {
          if (recorder.state === "recording") recorder.stop();
        }
      }, 100);

      setStatus("listening");
    } catch {
      setError("تعذر الوصول إلى الميكروفون — تأكد من إذن المتصفح");
    }
  }

  function stopRecording() {
    if (recRef.current && recRef.current.state === "recording") {
      recRef.current.stop();
    }
  }

  const keyDot =
    settings.configured === null ? "#9ca3af" : settings.configured ? "#22c55e" : "#ef4444";

  return (
    <div className="app">
      <header className="header">
        <div className="logo">🎙️ المساعد الصوتي</div>
        <div className="agents-strip">
          {Object.entries(AGENTS).map(([key, a]) => (
            <span key={key} className="agent-chip" style={{ borderColor: a.color }}>
              <span>{a.icon}</span> {a.label}
            </span>
          ))}
        </div>
        <button
          className="key-btn"
          onClick={() => setSettings((s) => ({ ...s, open: true, msg: "" }))}
          title="إضافة مفتاح API"
        >
          🔑 <span className="key-dot" style={{ background: keyDot }}></span>
        </button>
        <button className={`mute-btn ${muted ? "off" : ""}`} onClick={() => setMuted(!muted)}>
          {muted ? "🔇 الصوت مغلق" : "🔊 الصوت مفتوح"}
        </button>
      </header>

      <main className="chat">
        {messages.length === 0 && (
          <div className="empty">
            <div className="empty-icon">🎤</div>
            <p>اضغط زر الميكروفون وتحدث، أو اكتب طلبك بالأسفل</p>
            <p className="hint">مثال: «افتح المفكرة» أو «اعمل مستند وورد عن المبيعات»</p>
          </div>
        )}
        {messages.map((m, i) =>
          m.role === "user" ? (
            <div key={i} className="msg user">
              <div className="bubble user-bubble">{m.text}</div>
            </div>
          ) : (
            <div key={i} className="msg assistant">
              <div
                className="agent-tag"
                style={{ color: AGENTS[m.agent]?.color || "#fff" }}
              >
                {AGENTS[m.agent]?.icon} {AGENTS[m.agent]?.label || m.agent}
              </div>
              <div className="bubble assistant-bubble">{m.text}</div>
            </div>
          )
        )}
        {status === "thinking" && <div className="typing">⏳ {STATUS.thinking}</div>}
        <div ref={bottomRef} />
      </main>

      {pending && (
        <div className="confirm-overlay">
          <div className="confirm-card">
            <p>{pending.desc}</p>
            <div className="confirm-buttons">
              <button className="yes" onClick={() => answerConfirm(true)}>✅ نعم، نفّذ</button>
              <button className="no" onClick={() => answerConfirm(false)}>❌ لا، ألغِ</button>
            </div>
          </div>
        </div>
      )}

      {settings.open && (
        <div className="confirm-overlay">
          <div className="confirm-card key-card">
            <h3 className="key-title">🔑 مفتاح OpenAI API</h3>
            {settings.msg && <p className={`key-msg ${settings.issue ? "warn" : ""}`}>{settings.msg}</p>}
            <form onSubmit={saveApiKey}>
              <input
                className="key-input"
                type={settings.show ? "text" : "password"}
                value={settings.key}
                onChange={(e) => setSettings((s) => ({ ...s, key: e.target.value }))}
                placeholder="sk-..."
                dir="ltr"
                autoFocus
              />
              <button
                type="button"
                className="key-eye"
                onClick={() => setSettings((s) => ({ ...s, show: !s.show }))}
              >
                {settings.show ? "🙈" : "👁️"}
              </button>
              <div className="confirm-buttons">
                <button className="yes" type="submit" disabled={settings.saving || !settings.key.trim()}>
                  {settings.saving ? "جارٍ الحفظ..." : "💾 حفظ وتفعيل"}
                </button>
                {settings.configured && (
                  <button className="no" type="button" onClick={() => setSettings((s) => ({ ...s, open: false }))}>
                    إغلاق
                  </button>
                )}
              </div>
            </form>
            <p className="key-hint">
              المفتاح يُحفظ في ملف .env على جهازك فقط. احصل عليه من
              <a href="https://platform.openai.com/api-keys" target="_blank" rel="noreferrer"> platform.openai.com</a>
              {" "}أو استخدم Ollama المحلي المجاني بدلًا منه (راجع README).
            </p>
          </div>
        </div>
      )}

      {error && <div className="error">{error}</div>}

      <footer className="input-bar">
        <button
          className={`mic-btn ${status === "listening" ? "recording" : ""}`}
          onClick={status === "listening" ? stopRecording : startRecording}
          title="اضغط وتحدث"
        >
          {status === "listening" ? "⏹️" : "🎤"}
        </button>
        <form className="text-form" onSubmit={sendText}>
          <input
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder={STATUS[status] || "اكتب طلبك هنا..."}
            disabled={status !== "idle"}
          />
          <button type="submit" disabled={!text.trim() || status !== "idle"}>إرسال</button>
        </form>
      </footer>
      {status === "listening" && (
        <div className="status-line">{STATUS.listening}</div>
      )}
    </div>
  );
}
